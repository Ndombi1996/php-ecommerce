<?php
$page_title = 'Create Account';
require_once '../inc/header.php';

$error_message = '';
$success_message = '';

// Redirect if already logged in
if (Security::is_logged_in()) {
    header('Location: /account/dashboard.php');
    exit;
}

// Handle registration form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Security::verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        $name = Security::sanitize_input($_POST['name'] ?? '');
        $email = Security::sanitize_input($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        $referral_code = Security::sanitize_input($_POST['referral_code'] ?? '');
        
        // Validation
        if (empty($name) || empty($email) || empty($password)) {
            $error_message = 'Please fill in all required fields.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error_message = 'Please enter a valid email address.';
        } elseif (strlen($password) < 6) {
            $error_message = 'Password must be at least 6 characters long.';
        } elseif ($password !== $confirm_password) {
            $error_message = 'Passwords do not match.';
        } else {
            // Check if email already exists
            $users = JsonStore::read_json('users.json');
            $email_exists = false;
            
            foreach ($users as $user) {
                if (strtolower($user['email']) === strtolower($email)) {
                    $email_exists = true;
                    break;
                }
            }
            
            if ($email_exists) {
                $error_message = 'An account with this email already exists.';
            } else {
                // Validate referral code if provided
                $referred_by = null;
                if ($referral_code) {
                    $referrals = JsonStore::read_json('referrals.json');
                    foreach ($referrals as $referral) {
                        if ($referral['code'] === $referral_code) {
                            $referred_by = $referral['user_id'];
                            break;
                        }
                    }
                    
                    if (!$referred_by) {
                        $error_message = 'Invalid referral code.';
                    }
                }
                
                if (!$error_message) {
                    // Create new user
                    $user_id = JsonStore::generate_id('user_');
                    $user_referral_code = 'ref_' . substr(md5($user_id . time()), 0, 8);
                    
                    $new_user = [
                        'id' => $user_id,
                        'email' => $email,
                        'password_hash' => Security::hash_password($password),
                        'name' => $name,
                        'created_at' => date('c'),
                        'referral_code' => $user_referral_code,
                        'referred_by' => $referred_by,
                        'saved_addresses' => []
                    ];
                    
                    // Add user to users.json
                    $users[] = $new_user;
                    JsonStore::write_json('users.json', $users);
                    
                    // Create referral entry
                    $referrals = JsonStore::read_json('referrals.json');
                    $referrals[] = [
                        'code' => $user_referral_code,
                        'user_id' => $user_id,
                        'uses' => 0,
                        'discount_percent' => REFERRAL_DISCOUNT_PERCENT,
                        'created_at' => date('c')
                    ];
                    JsonStore::write_json('referrals.json', $referrals);
                    
                    // If referred by someone, increment their referral uses
                    if ($referred_by) {
                        foreach ($referrals as &$referral) {
                            if ($referral['user_id'] === $referred_by) {
                                $referral['uses']++;
                                break;
                            }
                        }
                        JsonStore::write_json('referrals.json', $referrals);
                    }
                    
                    // Auto-login the user
                    $_SESSION['user_id'] = $user_id;
                    $_SESSION['user_email'] = $email;
                    $_SESSION['user_name'] = $name;
                    
                    // Redirect to dashboard
                    header('Location: /account/dashboard.php?welcome=1');
                    exit;
                }
            }
        }
    }
}

// Check for referral code in URL
$url_referral = $_GET['ref'] ?? '';
?>

<div class="auth-page">
    <div class="container">
        <div class="auth-container">
            <div class="auth-card">
                <div class="auth-header">
                    <h1 class="auth-title">Create Your Account</h1>
                    <p class="auth-subtitle">Join us and start shopping for quality household items</p>
                </div>
                
                <?php if ($error_message): ?>
                    <div class="alert alert-error">
                        <?php echo htmlspecialchars($error_message); ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($url_referral): ?>
                    <div class="alert alert-info">
                        <strong>Referral Bonus!</strong> You'll get <?php echo REFERRAL_DISCOUNT_PERCENT; ?>% off your first order.
                    </div>
                <?php endif; ?>
                
                <form method="POST" class="auth-form">
                    <input type="hidden" name="csrf_token" value="<?php echo Security::generate_csrf_token(); ?>">
                    
                    <div class="form-group">
                        <label for="name">Full Name *</label>
                        <input type="text" id="name" name="name" required 
                               value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>"
                               class="form-input">
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email Address *</label>
                        <input type="email" id="email" name="email" required 
                               value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                               class="form-input">
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="password">Password *</label>
                            <input type="password" id="password" name="password" required 
                                   minlength="6" class="form-input">
                            <small class="form-help">At least 6 characters</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password">Confirm Password *</label>
                            <input type="password" id="confirm_password" name="confirm_password" required 
                                   minlength="6" class="form-input">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="referral_code">Referral Code (Optional)</label>
                        <input type="text" id="referral_code" name="referral_code" 
                               value="<?php echo htmlspecialchars($url_referral ?: ($_POST['referral_code'] ?? '')); ?>"
                               class="form-input" placeholder="Enter referral code for discount">
                        <small class="form-help">Get <?php echo REFERRAL_DISCOUNT_PERCENT; ?>% off your first order with a referral code</small>
                    </div>
                    
                    <div class="form-group">
                        <label class="checkbox-label">
                            <input type="checkbox" name="agree_terms" required>
                            <span class="checkmark"></span>
                            I agree to the <a href="/terms.php" target="_blank">Terms of Service</a> and <a href="/privacy.php" target="_blank">Privacy Policy</a>
                        </label>
                    </div>
                    
                    <div class="form-group">
                        <label class="checkbox-label">
                            <input type="checkbox" name="newsletter">
                            <span class="checkmark"></span>
                            Subscribe to our newsletter for deals and updates
                        </label>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-large btn-full">Create Account</button>
                </form>
                
                <div class="auth-footer">
                    <p>Already have an account? <a href="/auth/login.php" class="auth-link">Sign in here</a></p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../inc/footer.php'; ?>
