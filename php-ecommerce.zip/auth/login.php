<?php
$page_title = 'Login';
require_once '../inc/header.php';

$error_message = '';
$success_message = '';

// Redirect if already logged in
if (Security::is_logged_in()) {
    header('Location: /account/dashboard.php');
    exit;
}

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Security::verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        $email = Security::sanitize_input($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if (empty($email) || empty($password)) {
            $error_message = 'Please fill in all fields.';
        } else {
            // Find user by email
            $users = JsonStore::read_json('users.json');
            $user = null;
            
            foreach ($users as $u) {
                if (strtolower($u['email']) === strtolower($email)) {
                    $user = $u;
                    break;
                }
            }
            
            if ($user && Security::verify_password($password, $user['password_hash'])) {
                // Login successful
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_name'] = $user['name'];
                
                // Redirect to intended page or dashboard
                $redirect = $_GET['redirect'] ?? '/account/dashboard.php';
                header('Location: ' . $redirect);
                exit;
            } else {
                $error_message = 'Invalid email or password.';
            }
        }
    }
}
?>

<div class="auth-page">
    <div class="container">
        <div class="auth-container">
            <div class="auth-card">
                <div class="auth-header">
                    <h1 class="auth-title">Welcome Back</h1>
                    <p class="auth-subtitle">Sign in to your account to continue shopping</p>
                </div>
                
                <?php if ($error_message): ?>
                    <div class="alert alert-error">
                        <?php echo htmlspecialchars($error_message); ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($success_message): ?>
                    <div class="alert alert-success">
                        <?php echo htmlspecialchars($success_message); ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" class="auth-form">
                    <input type="hidden" name="csrf_token" value="<?php echo Security::generate_csrf_token(); ?>">
                    
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" required 
                               value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                               class="form-input">
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" required class="form-input">
                    </div>
                    
                    <div class="form-options">
                        <label class="checkbox-label">
                            <input type="checkbox" name="remember_me">
                            <span class="checkmark"></span>
                            Remember me
                        </label>
                        <a href="/auth/forgot-password.php" class="forgot-link">Forgot password?</a>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-large btn-full">Sign In</button>
                </form>
                
                <div class="auth-footer">
                    <p>Don't have an account? <a href="/auth/register.php" class="auth-link">Create one here</a></p>
                </div>
                
                <div class="demo-credentials">
                    <h4>Demo Credentials</h4>
                    <p><strong>Email:</strong> customer@example.com</p>
                    <p><strong>Password:</strong> password</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../inc/footer.php'; ?>
