<?php
$page_title = 'My Account';
require_once '../inc/header.php';

// Require login
Security::require_login();

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];

// Get user data
$user = JsonStore::find_by_id('users.json', $user_id);
if (!$user) {
    header('Location: /auth/logout.php');
    exit;
}

// Get user orders
$orders = JsonStore::read_json('orders.json');
$user_orders = array_filter($orders, function($order) use ($user_id) {
    return $order['user_id'] === $user_id;
});

// Sort orders by date (newest first)
usort($user_orders, function($a, $b) {
    return strtotime($b['created_at']) - strtotime($a['created_at']);
});

// Get referral stats
$referrals = JsonStore::read_json('referrals.json');
$user_referral = null;
foreach ($referrals as $referral) {
    if ($referral['user_id'] === $user_id) {
        $user_referral = $referral;
        break;
    }
}

$welcome_message = $_GET['welcome'] ?? '';
?>

<div class="account-page">
    <div class="container">
        <?php if ($welcome_message): ?>
            <div class="alert alert-success">
                <strong>Welcome to <?php echo SITE_NAME; ?>!</strong> Your account has been created successfully.
            </div>
        <?php endif; ?>
        
        <div class="account-header">
            <h1 class="page-title">My Account</h1>
            <p class="account-welcome">Welcome back, <?php echo htmlspecialchars($user_name); ?>!</p>
        </div>
        
        <div class="account-layout">
            <aside class="account-sidebar">
                <nav class="account-nav">
                    <a href="#overview" class="nav-item active" data-tab="overview">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" class="nav-icon">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 5a2 2 0 012-2h4a2 2 0 012 2v0H8v0z"></path>
                        </svg>
                        Overview
                    </a>
                    <a href="#orders" class="nav-item" data-tab="orders">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" class="nav-icon">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path>
                        </svg>
                        Orders
                    </a>
                    <a href="#referrals" class="nav-item" data-tab="referrals">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" class="nav-icon">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"></path>
                        </svg>
                        Referrals
                    </a>
                    <a href="#profile" class="nav-item" data-tab="profile">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" class="nav-icon">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                        </svg>
                        Profile
                    </a>
                </nav>
            </aside>
            
            <main class="account-main">
                <!-- Overview Tab -->
                <div class="tab-content active" id="overview">
                    <h2 class="tab-title">Account Overview</h2>
                    
                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="stat-icon">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path>
                                </svg>
                            </div>
                            <div class="stat-info">
                                <h3 class="stat-number"><?php echo count($user_orders); ?></h3>
                                <p class="stat-label">Total Orders</p>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
                                </svg>
                            </div>
                            <div class="stat-info">
                                <h3 class="stat-number">
                                    <?php 
                                    $total_spent = array_sum(array_column($user_orders, 'total'));
                                    echo CURRENCY_SYMBOL . number_format($total_spent, 2);
                                    ?>
                                </h3>
                                <p class="stat-label">Total Spent</p>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"></path>
                                </svg>
                            </div>
                            <div class="stat-info">
                                <h3 class="stat-number"><?php echo $user_referral ? $user_referral['uses'] : 0; ?></h3>
                                <p class="stat-label">Referrals</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="recent-orders">
                        <h3>Recent Orders</h3>
                        <?php if (empty($user_orders)): ?>
                            <div class="empty-state">
                                <p>You haven't placed any orders yet.</p>
                                <a href="/shop.php" class="btn btn-primary">Start Shopping</a>
                            </div>
                        <?php else: ?>
                            <div class="orders-list">
                                <?php foreach (array_slice($user_orders, 0, 3) as $order): ?>
                                    <div class="order-card">
                                        <div class="order-header">
                                            <div class="order-info">
                                                <h4 class="order-id">Order #<?php echo htmlspecialchars($order['id']); ?></h4>
                                                <p class="order-date"><?php echo date('M j, Y', strtotime($order['created_at'])); ?></p>
                                            </div>
                                            <div class="order-status">
                                                <span class="status-badge status-<?php echo $order['status']; ?>">
                                                    <?php echo ucfirst($order['status']); ?>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="order-details">
                                            <p class="order-items"><?php echo count($order['items']); ?> item(s)</p>
                                            <p class="order-total"><?php echo CURRENCY_SYMBOL . number_format($order['total'], 2); ?></p>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <a href="#orders" class="btn btn-outline view-all-btn" data-tab="orders">View All Orders</a>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Orders Tab -->
                <div class="tab-content" id="orders">
                    <h2 class="tab-title">Order History</h2>
                    
                    <?php if (empty($user_orders)): ?>
                        <div class="empty-state">
                            <div class="empty-icon">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path>
                                </svg>
                            </div>
                            <h3>No orders yet</h3>
                            <p>When you place your first order, it will appear here.</p>
                            <a href="/shop.php" class="btn btn-primary">Start Shopping</a>
                        </div>
                    <?php else: ?>
                        <div class="orders-table">
                            <?php foreach ($user_orders as $order): ?>
                                <div class="order-row">
                                    <div class="order-summary">
                                        <div class="order-main-info">
                                            <h4 class="order-number">Order #<?php echo htmlspecialchars($order['id']); ?></h4>
                                            <p class="order-date"><?php echo date('F j, Y \a\t g:i A', strtotime($order['created_at'])); ?></p>
                                            <span class="status-badge status-<?php echo $order['status']; ?>">
                                                <?php echo ucfirst($order['status']); ?>
                                            </span>
                                        </div>
                                        <div class="order-totals">
                                            <p class="order-items-count"><?php echo count($order['items']); ?> item(s)</p>
                                            <p class="order-amount"><?php echo CURRENCY_SYMBOL . number_format($order['total'], 2); ?></p>
                                        </div>
                                    </div>
                                    
                                    <div class="order-items">
                                        <?php foreach ($order['items'] as $item): ?>
                                            <div class="order-item">
                                                <span class="item-name"><?php echo htmlspecialchars($item['title']); ?></span>
                                                <span class="item-quantity">Qty: <?php echo $item['quantity']; ?></span>
                                                <span class="item-price"><?php echo CURRENCY_SYMBOL . number_format($item['unit_price'] * $item['quantity'], 2); ?></span>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Referrals Tab -->
                <div class="tab-content" id="referrals">
                    <h2 class="tab-title">Referral Program</h2>
                    
                    <div class="referral-info">
                        <div class="referral-card">
                            <h3>Your Referral Code</h3>
                            <div class="referral-code-display">
                                <input type="text" value="<?php echo htmlspecialchars($user_referral['code'] ?? ''); ?>" 
                                       readonly class="referral-code-input" id="referralCode">
                                <button class="btn btn-outline btn-sm copy-btn" onclick="copyReferralCode()">Copy</button>
                            </div>
                            <p class="referral-description">
                                Share this code with friends and they'll get <?php echo REFERRAL_DISCOUNT_PERCENT; ?>% off their first order!
                            </p>
                        </div>
                        
                        <div class="referral-link-card">
                            <h3>Your Referral Link</h3>
                            <div class="referral-code-display">
                                <input type="text" value="<?php echo SITE_URL; ?>/auth/register.php?ref=<?php echo htmlspecialchars($user_referral['code'] ?? ''); ?>" 
                                       readonly class="referral-code-input" id="referralLink">
                                <button class="btn btn-outline btn-sm copy-btn" onclick="copyReferralLink()">Copy</button>
                            </div>
                            <p class="referral-description">
                                Or share this direct link for easy registration.
                            </p>
                        </div>
                    </div>
                    
                    <div class="referral-stats">
                        <div class="stat-card">
                            <h4>Total Referrals</h4>
                            <p class="stat-number"><?php echo $user_referral ? $user_referral['uses'] : 0; ?></p>
                        </div>
                        <div class="stat-card">
                            <h4>Discount Rate</h4>
                            <p class="stat-number"><?php echo REFERRAL_DISCOUNT_PERCENT; ?>%</p>
                        </div>
                    </div>
                </div>
                
                <!-- Profile Tab -->
                <div class="tab-content" id="profile">
                    <h2 class="tab-title">Profile Settings</h2>
                    
                    <div class="profile-section">
                        <h3>Personal Information</h3>
                        <div class="profile-info">
                            <div class="info-row">
                                <label>Name:</label>
                                <span><?php echo htmlspecialchars($user['name']); ?></span>
                            </div>
                            <div class="info-row">
                                <label>Email:</label>
                                <span><?php echo htmlspecialchars($user['email']); ?></span>
                            </div>
                            <div class="info-row">
                                <label>Member Since:</label>
                                <span><?php echo date('F j, Y', strtotime($user['created_at'])); ?></span>
                            </div>
                        </div>
                        <button class="btn btn-outline">Edit Profile</button>
                    </div>
                    
                    <div class="profile-section">
                        <h3>Account Actions</h3>
                        <div class="action-buttons">
                            <button class="btn btn-outline">Change Password</button>
                            <a href="/auth/logout.php" class="btn btn-secondary">Sign Out</a>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</div>

<script>
// Account dashboard JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Tab navigation
    const navItems = document.querySelectorAll('.nav-item');
    const tabContents = document.querySelectorAll('.tab-content');
    
    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const targetTab = this.dataset.tab;
            
            // Remove active class from all nav items and tab contents
            navItems.forEach(nav => nav.classList.remove('active'));
            tabContents.forEach(tab => tab.classList.remove('active'));
            
            // Add active class to clicked nav item and corresponding tab
            this.classList.add('active');
            document.getElementById(targetTab).classList.add('active');
        });
    });
    
    // Handle view all orders button
    const viewAllBtn = document.querySelector('.view-all-btn');
    if (viewAllBtn) {
        viewAllBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const targetTab = this.dataset.tab;
            
            navItems.forEach(nav => nav.classList.remove('active'));
            tabContents.forEach(tab => tab.classList.remove('active'));
            
            document.querySelector(`[data-tab="${targetTab}"]`).classList.add('active');
            document.getElementById(targetTab).classList.add('active');
        });
    }
});

function copyReferralCode() {
    const codeInput = document.getElementById('referralCode');
    codeInput.select();
    document.execCommand('copy');
    showToast('Referral code copied to clipboard!', 'success');
}

function copyReferralLink() {
    const linkInput = document.getElementById('referralLink');
    linkInput.select();
    document.execCommand('copy');
    showToast('Referral link copied to clipboard!', 'success');
}
</script>

<?php require_once '../inc/footer.php'; ?>
