<?php
session_start();
require_once '../inc/json_store.php';
require_once '../inc/security.php';

// Check admin authentication
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

$store = new JsonStore();
$orders = $store->read('orders');
$users = $store->read('users');

// Create user lookup array
$user_lookup = [];
foreach ($users as $user) {
    $user_lookup[$user['id']] = $user;
}

// Handle status updates
if ($_POST && isset($_POST['update_status'])) {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }
    
    foreach ($orders as &$order) {
        if ($order['id'] === $_POST['order_id']) {
            $order['status'] = sanitize_input($_POST['status']);
            $order['updated_at'] = date('Y-m-d H:i:s');
            break;
        }
    }
    $store->write('orders', $orders);
    header('Location: orders.php');
    exit;
}

// Sort orders by date (newest first)
usort($orders, function($a, $b) {
    return strtotime($b['created_at']) - strtotime($a['created_at']);
});

include 'header.php';
?>

<div class="admin-content">
    <div class="admin-header">
        <h1>Order Management</h1>
        <div class="admin-stats">
            <div class="stat-card">
                <h3><?php echo count($orders); ?></h3>
                <p>Total Orders</p>
            </div>
            <div class="stat-card">
                <h3><?php echo count(array_filter($orders, function($o) { return $o['status'] === 'pending'; })); ?></h3>
                <p>Pending</p>
            </div>
            <div class="stat-card">
                <h3><?php echo count(array_filter($orders, function($o) { return $o['status'] === 'completed'; })); ?></h3>
                <p>Completed</p>
            </div>
        </div>
    </div>

    <div class="admin-card">
        <div class="table-responsive">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Customer</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                    <tr>
                        <td>#<?php echo substr($order['id'], -8); ?></td>
                        <td>
                            <?php 
                            $user = $user_lookup[$order['user_id']] ?? null;
                            echo $user ? htmlspecialchars($user['name']) : 'Guest';
                            ?>
                        </td>
                        <td>$<?php echo number_format($order['total'], 2); ?></td>
                        <td>
                            <span class="status-badge status-<?php echo $order['status']; ?>">
                                <?php echo ucfirst($order['status']); ?>
                            </span>
                        </td>
                        <td><?php echo date('M j, Y g:i A', strtotime($order['created_at'])); ?></td>
                        <td>
                            <button class="btn btn-sm btn-primary" onclick="viewOrder('<?php echo $order['id']; ?>')">View</button>
                            <button class="btn btn-sm btn-secondary" onclick="updateStatus('<?php echo $order['id']; ?>', '<?php echo $order['status']; ?>')">Update Status</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Order Details Modal -->
<div id="orderModal" class="modal">
    <div class="modal-content modal-large">
        <div class="modal-header">
            <h3>Order Details</h3>
            <span class="close" onclick="closeModal()">&times;</span>
        </div>
        <div id="orderDetails"></div>
    </div>
</div>

<!-- Status Update Modal -->
<div id="statusModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Update Order Status</h3>
            <span class="close" onclick="closeStatusModal()">&times;</span>
        </div>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
            <input type="hidden" name="update_status" value="1">
            <input type="hidden" name="order_id" id="statusOrderId">
            
            <div class="form-group">
                <label for="status">Order Status</label>
                <select name="status" id="orderStatus" required>
                    <option value="pending">Pending</option>
                    <option value="processing">Processing</option>
                    <option value="shipped">Shipped</option>
                    <option value="delivered">Delivered</option>
                    <option value="cancelled">Cancelled</option>
                </select>
            </div>
            
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeStatusModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Update Status</button>
            </div>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>
