<?php
$page_title = 'Products';
require_once 'header.php';

$success_message = '';
$error_message = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Security::verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error_message = 'Invalid security token.';
    } else {
        $action = $_POST['action'] ?? '';
        
        switch ($action) {
            case 'add':
            case 'edit':
                $product_id = $action === 'edit' ? ($_POST['product_id'] ?? '') : JsonStore::generate_id('prod_');
                $title = Security::sanitize_input($_POST['title'] ?? '');
                $slug = strtolower(preg_replace('/[^a-zA-Z0-9]+/', '-', $title));
                $category_id = Security::sanitize_input($_POST['category_id'] ?? '');
                $price = floatval($_POST['price'] ?? 0);
                $stock = intval($_POST['stock'] ?? 0);
                $status = Security::sanitize_input($_POST['status'] ?? 'active');
                $short_description = Security::sanitize_input($_POST['short_description'] ?? '');
                $long_description = Security::sanitize_input($_POST['long_description'] ?? '');
                
                // Validate required fields
                if (empty($title) || empty($category_id) || $price <= 0) {
                    $error_message = 'Please fill in all required fields.';
                } else {
                    $product_data = [
                        'id' => $product_id,
                        'title' => $title,
                        'slug' => $slug,
                        'category_id' => $category_id,
                        'price' => $price,
                        'currency' => 'USD',
                        'stock' => $stock,
                        'status' => $status,
                        'images' => [],
                        'short_description' => $short_description,
                        'long_description' => $long_description,
                        'attributes' => [],
                        'created_at' => $action === 'add' ? date('c') : ($_POST['created_at'] ?? date('c'))
                    ];
                    
                    $products = JsonStore::read_json('products.json');
                    
                    if ($action === 'add') {
                        $products[] = $product_data;
                        $success_message = 'Product added successfully!';
                    } else {
                        // Update existing product
                        foreach ($products as $key => $product) {
                            if ($product['id'] === $product_id) {
                                $products[$key] = $product_data;
                                break;
                            }
                        }
                        $success_message = 'Product updated successfully!';
                    }
                    
                    JsonStore::write_json('products.json', $products);
                }
                break;
                
            case 'delete':
                $product_id = $_POST['product_id'] ?? '';
                if ($product_id) {
                    JsonStore::delete_by_id('products.json', $product_id);
                    $success_message = 'Product deleted successfully!';
                }
                break;
        }
    }
}

// Get products and categories
$products = JsonStore::read_json('products.json');
$categories = JsonStore::read_json('categories.json');

// Handle edit mode
$edit_product = null;
if (isset($_GET['edit'])) {
    $edit_product = JsonStore::find_by_id('products.json', $_GET['edit']);
}

$show_form = isset($_GET['action']) && ($_GET['action'] === 'add' || $_GET['action'] === 'edit') || $edit_product;
?>

<?php if ($success_message): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
<?php endif; ?>

<?php if ($error_message): ?>
    <div class="alert alert-error"><?php echo htmlspecialchars($error_message); ?></div>
<?php endif; ?>

<div class="admin-toolbar">
    <div class="toolbar-left">
        <h2>Products Management</h2>
    </div>
    <div class="toolbar-right">
        <?php if (!$show_form): ?>
            <a href="?action=add" class="btn btn-primary">Add New Product</a>
        <?php else: ?>
            <a href="/admin/products.php" class="btn btn-outline">Back to List</a>
        <?php endif; ?>
    </div>
</div>

<?php if ($show_form): ?>
    <!-- Add/Edit Product Form -->
    <div class="admin-card">
        <div class="card-header">
            <h3><?php echo $edit_product ? 'Edit Product' : 'Add New Product'; ?></h3>
        </div>
        <div class="card-content">
            <form method="POST" class="admin-form">
                <input type="hidden" name="csrf_token" value="<?php echo Security::generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="<?php echo $edit_product ? 'edit' : 'add'; ?>">
                <?php if ($edit_product): ?>
                    <input type="hidden" name="product_id" value="<?php echo $edit_product['id']; ?>">
                    <input type="hidden" name="created_at" value="<?php echo $edit_product['created_at']; ?>">
                <?php endif; ?>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="title">Product Title *</label>
                        <input type="text" id="title" name="title" required 
                               value="<?php echo htmlspecialchars($edit_product['title'] ?? ''); ?>"
                               class="form-input">
                    </div>
                    
                    <div class="form-group">
                        <label for="category_id">Category *</label>
                        <select id="category_id" name="category_id" required class="form-input">
                            <option value="">Select Category</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?php echo $category['id']; ?>" 
                                        <?php echo ($edit_product['category_id'] ?? '') === $category['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($category['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="price">Price (USD) *</label>
                        <input type="number" id="price" name="price" step="0.01" min="0" required 
                               value="<?php echo $edit_product['price'] ?? ''; ?>"
                               class="form-input">
                    </div>
                    
                    <div class="form-group">
                        <label for="stock">Stock Quantity</label>
                        <input type="number" id="stock" name="stock" min="0" 
                               value="<?php echo $edit_product['stock'] ?? 0; ?>"
                               class="form-input">
                    </div>
                    
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select id="status" name="status" class="form-input">
                            <option value="active" <?php echo ($edit_product['status'] ?? 'active') === 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="inactive" <?php echo ($edit_product['status'] ?? '') === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                            <option value="coming_soon" <?php echo ($edit_product['status'] ?? '') === 'coming_soon' ? 'selected' : ''; ?>>Coming Soon</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="short_description">Short Description</label>
                    <input type="text" id="short_description" name="short_description" 
                           value="<?php echo htmlspecialchars($edit_product['short_description'] ?? ''); ?>"
                           class="form-input" maxlength="200">
                    <small class="form-help">Brief description for product cards</small>
                </div>
                
                <div class="form-group">
                    <label for="long_description">Long Description</label>
                    <textarea id="long_description" name="long_description" rows="4" class="form-input"><?php echo htmlspecialchars($edit_product['long_description'] ?? ''); ?></textarea>
                    <small class="form-help">Detailed description for product page</small>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <?php echo $edit_product ? 'Update Product' : 'Add Product'; ?>
                    </button>
                    <a href="/admin/products.php" class="btn btn-outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>
<?php else: ?>
    <!-- Products List -->
    <div class="admin-card">
        <div class="card-content">
            <div class="table-container">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($products)): ?>
                            <tr>
                                <td colspan="6" class="empty-message">No products found. <a href="?action=add">Add your first product</a></td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($products as $product): ?>
                                <?php
                                $category = array_filter($categories, function($cat) use ($product) {
                                    return $cat['id'] === $product['category_id'];
                                });
                                $category = reset($category);
                                ?>
                                <tr>
                                    <td>
                                        <div class="product-info">
                                            <strong><?php echo htmlspecialchars($product['title']); ?></strong>
                                            <small><?php echo htmlspecialchars($product['short_description']); ?></small>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($category['name'] ?? 'Unknown'); ?></td>
                                    <td><?php echo CURRENCY_SYMBOL . number_format($product['price'], 2); ?></td>
                                    <td>
                                        <span class="stock-indicator <?php echo $product['stock'] <= 10 ? 'low' : 'normal'; ?>">
                                            <?php echo $product['stock']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="status-badge status-<?php echo $product['status']; ?>">
                                            <?php echo ucfirst($product['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="?edit=<?php echo $product['id']; ?>" class="btn btn-sm btn-outline">Edit</a>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this product?');">
                                                <input type="hidden" name="csrf_token" value="<?php echo Security::generate_csrf_token(); ?>">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                                <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php require_once 'footer.php'; ?>
