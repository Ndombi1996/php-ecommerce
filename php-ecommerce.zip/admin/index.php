<?php
$page_title = 'Admin Login';
require_once '../inc/config.php';

$error_message = '';

// Redirect if already logged in as admin
if (Security::is_admin()) {
    header('Location: /admin/dashboard.php');
    exit;
}

// Handle admin login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Security::verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        $username = Security::sanitize_input($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            $error_message = 'Please fill in all fields.';
        } else {
            // Find admin by username
            $admins = JsonStore::read_json('admins.json');
            $admin = null;
            
            foreach ($admins as $a) {
                if (strtolower($a['username']) === strtolower($username)) {
                    $admin = $a;
                    break;
                }
            }
            
            if ($admin && Security::verify_password($password, $admin['password_hash'])) {
                // Login successful
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_username'] = $admin['username'];
                $_SESSION['admin_name'] = $admin['name'];
                
                header('Location: /admin/dashboard.php');
                exit;
            } else {
                $error_message = 'Invalid username or password.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;600;700&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
    <link href="/assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="admin-login-page">
        <div class="admin-login-container">
            <div class="admin-login-card">
                <div class="admin-header">
                    <h1 class="admin-title"><?php echo SITE_NAME; ?> Admin</h1>
                    <p class="admin-subtitle">Sign in to access the admin dashboard</p>
                </div>
                
                <?php if ($error_message): ?>
                    <div class="alert alert-error">
                        <?php echo htmlspecialchars($error_message); ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" class="admin-form">
                    <input type="hidden" name="csrf_token" value="<?php echo Security::generate_csrf_token(); ?>">
                    
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" required 
                               value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                               class="form-input">
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" required class="form-input">
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-large btn-full">Sign In</button>
                </form>
                
                <div class="demo-credentials">
                    <h4>Demo Credentials</h4>
                    <p><strong>Username:</strong> admin</p>
                    <p><strong>Password:</strong> password</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
