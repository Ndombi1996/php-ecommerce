<?php
session_start();
require_once '../inc/json_store.php';
require_once '../inc/security.php';

// Check admin authentication
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

$store = new JsonStore();
$orders = $store->read('orders');
$products = $store->read('products');
$users = $store->read('users');

// Calculate analytics
$total_revenue = array_sum(array_column($orders, 'total'));
$total_orders = count($orders);
$total_customers = count($users);
$avg_order_value = $total_orders > 0 ? $total_revenue / $total_orders : 0;

// Monthly sales data
$monthly_sales = [];
foreach ($orders as $order) {
    $month = date('Y-m', strtotime($order['created_at']));
    if (!isset($monthly_sales[$month])) {
        $monthly_sales[$month] = 0;
    }
    $monthly_sales[$month] += $order['total'];
}

// Top selling products
$product_sales = [];
foreach ($orders as $order) {
    foreach ($order['items'] as $item) {
        if (!isset($product_sales[$item['product_id']])) {
            $product_sales[$item['product_id']] = 0;
        }
        $product_sales[$item['product_id']] += $item['quantity'];
    }
}
arsort($product_sales);

include 'header.php';
?>

<div class="admin-content">
    <div class="admin-header">
        <h1>Analytics & Reports</h1>
    </div>

    <div class="analytics-grid">
        <div class="analytics-card">
            <h3>Total Revenue</h3>
            <div class="metric">$<?php echo number_format($total_revenue, 2); ?></div>
        </div>
        <div class="analytics-card">
            <h3>Total Orders</h3>
            <div class="metric"><?php echo $total_orders; ?></div>
        </div>
        <div class="analytics-card">
            <h3>Total Customers</h3>
            <div class="metric"><?php echo $total_customers; ?></div>
        </div>
        <div class="analytics-card">
            <h3>Avg Order Value</h3>
            <div class="metric">$<?php echo number_format($avg_order_value, 2); ?></div>
        </div>
    </div>

    <div class="chart-container">
        <div class="admin-card">
            <h3>Monthly Sales</h3>
            <canvas id="salesChart" width="400" height="200"></canvas>
        </div>
    </div>

    <div class="admin-card">
        <h3>Top Selling Products</h3>
        <div class="table-responsive">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Units Sold</th>
                        <th>Revenue</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $count = 0;
                    foreach ($product_sales as $product_id => $quantity): 
                        if ($count >= 10) break;
                        $product = array_filter($products, function($p) use ($product_id) {
                            return $p['id'] === $product_id;
                        });
                        $product = reset($product);
                        if ($product):
                            $revenue = $quantity * $product['price'];
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($product['name']); ?></td>
                        <td><?php echo $quantity; ?></td>
                        <td>$<?php echo number_format($revenue, 2); ?></td>
                    </tr>
                    <?php 
                        endif;
                        $count++;
                    endforeach; 
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// Sales chart data
const salesData = <?php echo json_encode($monthly_sales); ?>;
const months = Object.keys(salesData);
const sales = Object.values(salesData);

// Simple canvas chart
const canvas = document.getElementById('salesChart');
const ctx = canvas.getContext('2d');

// Draw simple bar chart
function drawChart() {
    const padding = 40;
    const chartWidth = canvas.width - (padding * 2);
    const chartHeight = canvas.height - (padding * 2);
    const maxSale = Math.max(...sales);
    const barWidth = chartWidth / months.length;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw bars
    sales.forEach((sale, index) => {
        const barHeight = (sale / maxSale) * chartHeight;
        const x = padding + (index * barWidth) + (barWidth * 0.1);
        const y = canvas.height - padding - barHeight;
        const width = barWidth * 0.8;
        
        ctx.fillStyle = '#ea580c';
        ctx.fillRect(x, y, width, barHeight);
        
        // Draw month labels
        ctx.fillStyle = '#374151';
        ctx.font = '12px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(months[index], x + width/2, canvas.height - 10);
        
        // Draw values
        ctx.fillText('$' + sale.toFixed(0), x + width/2, y - 5);
    });
}

drawChart();
</script>

<?php include 'footer.php'; ?>
