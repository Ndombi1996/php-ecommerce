<?php
session_start();
require_once '../inc/json_store.php';
require_once '../inc/security.php';

// Check admin authentication
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

$store = new JsonStore();
$coupons = $store->read('coupons');

// Handle form submissions
if ($_POST) {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }
    
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $new_coupon = [
                    'id' => uniqid(),
                    'code' => strtoupper(sanitize_input($_POST['code'])),
                    'type' => sanitize_input($_POST['type']),
                    'value' => floatval($_POST['value']),
                    'min_amount' => floatval($_POST['min_amount']),
                    'max_uses' => intval($_POST['max_uses']),
                    'used_count' => 0,
                    'expires_at' => sanitize_input($_POST['expires_at']),
                    'active' => true,
                    'created_at' => date('Y-m-d H:i:s')
                ];
                $coupons[] = $new_coupon;
                $store->write('coupons', $coupons);
                break;
                
            case 'toggle':
                foreach ($coupons as &$coupon) {
                    if ($coupon['id'] === $_POST['id']) {
                        $coupon['active'] = !$coupon['active'];
                        break;
                    }
                }
                $store->write('coupons', $coupons);
                break;
                
            case 'delete':
                $coupons = array_filter($coupons, function($c) {
                    return $c['id'] !== $_POST['id'];
                });
                $store->write('coupons', array_values($coupons));
                break;
        }
    }
    header('Location: coupons.php');
    exit;
}

include 'header.php';
?>

<div class="admin-content">
    <div class="admin-header">
        <h1>Coupon Management</h1>
        <button class="btn btn-primary" onclick="showAddModal()">Create New Coupon</button>
    </div>

    <div class="admin-card">
        <div class="table-responsive">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Type</th>
                        <th>Value</th>
                        <th>Min Amount</th>
                        <th>Usage</th>
                        <th>Expires</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($coupons as $coupon): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($coupon['code']); ?></strong></td>
                        <td><?php echo ucfirst($coupon['type']); ?></td>
                        <td>
                            <?php 
                            echo $coupon['type'] === 'percentage' 
                                ? $coupon['value'] . '%' 
                                : '$' . number_format($coupon['value'], 2);
                            ?>
                        </td>
                        <td>$<?php echo number_format($coupon['min_amount'], 2); ?></td>
                        <td><?php echo $coupon['used_count']; ?>/<?php echo $coupon['max_uses']; ?></td>
                        <td><?php echo date('M j, Y', strtotime($coupon['expires_at'])); ?></td>
                        <td>
                            <span class="status-badge status-<?php echo $coupon['active'] ? 'active' : 'inactive'; ?>">
                                <?php echo $coupon['active'] ? 'Active' : 'Inactive'; ?>
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-secondary" onclick="toggleCoupon('<?php echo $coupon['id']; ?>')">
                                <?php echo $coupon['active'] ? 'Deactivate' : 'Activate'; ?>
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="deleteCoupon('<?php echo $coupon['id']; ?>')">Delete</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Coupon Modal -->
<div id="couponModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Create New Coupon</h3>
            <span class="close" onclick="closeModal()">&times;</span>
        </div>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
            <input type="hidden" name="action" value="add">
            
            <div class="form-group">
                <label for="code">Coupon Code</label>
                <input type="text" id="code" name="code" required placeholder="e.g., SAVE20">
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="type">Discount Type</label>
                    <select id="type" name="type" required>
                        <option value="percentage">Percentage</option>
                        <option value="fixed">Fixed Amount</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="value">Discount Value</label>
                    <input type="number" id="value" name="value" step="0.01" required>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="min_amount">Minimum Order Amount</label>
                    <input type="number" id="min_amount" name="min_amount" step="0.01" value="0">
                </div>
                <div class="form-group">
                    <label for="max_uses">Maximum Uses</label>
                    <input type="number" id="max_uses" name="max_uses" value="100">
                </div>
            </div>
            
            <div class="form-group">
                <label for="expires_at">Expiration Date</label>
                <input type="date" id="expires_at" name="expires_at" required>
            </div>
            
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Create Coupon</button>
            </div>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>
