</div>
        </main>
    </div>
    
    <script src="/assets/js/app.js"></script>
    <script src="/assets/js/admin.js"></script>
</body>
</html>
