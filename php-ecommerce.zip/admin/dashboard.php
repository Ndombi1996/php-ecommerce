<?php
$page_title = 'Dashboard';
require_once 'header.php';

// Get dashboard statistics
$products = JsonStore::read_json('products.json');
$orders = JsonStore::read_json('orders.json');
$users = JsonStore::read_json('users.json');

// Calculate stats
$total_products = count($products);
$active_products = count(array_filter($products, function($p) { return $p['status'] === 'active'; }));
$low_stock_products = count(array_filter($products, function($p) { return $p['stock'] <= 10 && $p['stock'] > 0; }));

$total_orders = count($orders);
$pending_orders = count(array_filter($orders, function($o) { return $o['status'] === 'pending'; }));
$total_revenue = array_sum(array_column($orders, 'total'));

$total_users = count($users);

// Recent orders (last 5)
$recent_orders = array_slice(array_reverse($orders), 0, 5);

// Sales data for chart (last 7 days)
$sales_data = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $day_orders = array_filter($orders, function($order) use ($date) {
        return date('Y-m-d', strtotime($order['created_at'])) === $date;
    });
    $sales_data[] = [
        'date' => $date,
        'sales' => array_sum(array_column($day_orders, 'total')),
        'orders' => count($day_orders)
    ];
}
?>

<div class="dashboard-grid">
    <!-- Stats Cards -->
    <div class="stats-row">
        <div class="stat-card">
            <div class="stat-icon products">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
                </svg>
            </div>
            <div class="stat-content">
                <h3 class="stat-number"><?php echo $total_products; ?></h3>
                <p class="stat-label">Total Products</p>
                <span class="stat-detail"><?php echo $active_products; ?> active</span>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon orders">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path>
                </svg>
            </div>
            <div class="stat-content">
                <h3 class="stat-number"><?php echo $total_orders; ?></h3>
                <p class="stat-label">Total Orders</p>
                <span class="stat-detail"><?php echo $pending_orders; ?> pending</span>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon revenue">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
                </svg>
            </div>
            <div class="stat-content">
                <h3 class="stat-number"><?php echo CURRENCY_SYMBOL . number_format($total_revenue, 2); ?></h3>
                <p class="stat-label">Total Revenue</p>
                <span class="stat-detail">All time</span>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon users">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"></path>
                </svg>
            </div>
            <div class="stat-content">
                <h3 class="stat-number"><?php echo $total_users; ?></h3>
                <p class="stat-label">Total Users</p>
                <span class="stat-detail">Registered</span>
            </div>
        </div>
    </div>
    
    <!-- Charts and Tables Row -->
    <div class="dashboard-row">
        <div class="dashboard-card chart-card">
            <div class="card-header">
                <h3>Sales Overview (Last 7 Days)</h3>
            </div>
            <div class="card-content">
                <canvas id="salesChart" width="400" height="200"></canvas>
            </div>
        </div>
        
        <div class="dashboard-card">
            <div class="card-header">
                <h3>Quick Actions</h3>
            </div>
            <div class="card-content">
                <div class="quick-actions">
                    <a href="/admin/products.php?action=add" class="quick-action">
                        <div class="action-icon">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                            </svg>
                        </div>
                        <span>Add Product</span>
                    </a>
                    
                    <a href="/admin/categories.php?action=add" class="quick-action">
                        <div class="action-icon">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path>
                            </svg>
                        </div>
                        <span>Add Category</span>
                    </a>
                    
                    <a href="/admin/orders.php" class="quick-action">
                        <div class="action-icon">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                            </svg>
                        </div>
                        <span>View Orders</span>
                    </a>
                    
                    <a href="/admin/analytics.php" class="quick-action">
                        <div class="action-icon">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
                            </svg>
                        </div>
                        <span>Analytics</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Recent Orders and Alerts -->
    <div class="dashboard-row">
        <div class="dashboard-card">
            <div class="card-header">
                <h3>Recent Orders</h3>
                <a href="/admin/orders.php" class="card-link">View All</a>
            </div>
            <div class="card-content">
                <?php if (empty($recent_orders)): ?>
                    <p class="empty-message">No orders yet.</p>
                <?php else: ?>
                    <div class="orders-table">
                        <?php foreach ($recent_orders as $order): ?>
                            <div class="order-row">
                                <div class="order-info">
                                    <span class="order-id">#<?php echo htmlspecialchars($order['id']); ?></span>
                                    <span class="order-date"><?php echo date('M j, Y', strtotime($order['created_at'])); ?></span>
                                </div>
                                <div class="order-details">
                                    <span class="order-total"><?php echo CURRENCY_SYMBOL . number_format($order['total'], 2); ?></span>
                                    <span class="status-badge status-<?php echo $order['status']; ?>">
                                        <?php echo ucfirst($order['status']); ?>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="dashboard-card">
            <div class="card-header">
                <h3>Alerts & Notifications</h3>
            </div>
            <div class="card-content">
                <div class="alerts-list">
                    <?php if ($low_stock_products > 0): ?>
                        <div class="alert-item warning">
                            <div class="alert-icon">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"></path>
                                </svg>
                            </div>
                            <div class="alert-content">
                                <strong>Low Stock Alert</strong>
                                <p><?php echo $low_stock_products; ?> product(s) running low on stock</p>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($pending_orders > 0): ?>
                        <div class="alert-item info">
                            <div class="alert-icon">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                            </div>
                            <div class="alert-content">
                                <strong>Pending Orders</strong>
                                <p><?php echo $pending_orders; ?> order(s) need attention</p>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($low_stock_products === 0 && $pending_orders === 0): ?>
                        <div class="alert-item success">
                            <div class="alert-icon">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                            </div>
                            <div class="alert-content">
                                <strong>All Good!</strong>
                                <p>No urgent issues require attention</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Sales chart
document.addEventListener('DOMContentLoaded', function() {
    const canvas = document.getElementById('salesChart');
    const ctx = canvas.getContext('2d');
    
    const salesData = <?php echo json_encode($sales_data); ?>;
    const dates = salesData.map(d => new Date(d.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
    const sales = salesData.map(d => d.sales);
    
    // Simple chart drawing
    const padding = 40;
    const chartWidth = canvas.width - (padding * 2);
    const chartHeight = canvas.height - (padding * 2);
    
    const maxSales = Math.max(...sales, 100);
    const minSales = 0;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw grid lines
    ctx.strokeStyle = '#e5e7eb';
    ctx.lineWidth = 1;
    
    // Horizontal grid lines
    for (let i = 0; i <= 5; i++) {
        const y = padding + (chartHeight / 5) * i;
        ctx.beginPath();
        ctx.moveTo(padding, y);
        ctx.lineTo(canvas.width - padding, y);
        ctx.stroke();
    }
    
    // Draw line chart
    ctx.strokeStyle = '#ea580c';
    ctx.lineWidth = 3;
    ctx.beginPath();
    
    sales.forEach((sale, index) => {
        const x = padding + (chartWidth / (sales.length - 1)) * index;
        const y = padding + chartHeight - ((sale - minSales) / (maxSales - minSales)) * chartHeight;
        
        if (index === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    });
    
    ctx.stroke();
    
    // Draw data points
    ctx.fillStyle = '#ea580c';
    sales.forEach((sale, index) => {
        const x = padding + (chartWidth / (sales.length - 1)) * index;
        const y = padding + chartHeight - ((sale - minSales) / (maxSales - minSales)) * chartHeight;
        
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, 2 * Math.PI);
        ctx.fill();
    });
    
    // Draw labels
    ctx.fillStyle = '#6b7280';
    ctx.font = '12px DM Sans';
    ctx.textAlign = 'center';
    
    dates.forEach((date, index) => {
        const x = padding + (chartWidth / (dates.length - 1)) * index;
        ctx.fillText(date, x, canvas.height - 10);
    });
    
    // Y-axis labels
    ctx.textAlign = 'right';
    for (let i = 0; i <= 5; i++) {
        const value = minSales + ((maxSales - minSales) / 5) * (5 - i);
        const y = padding + (chartHeight / 5) * i + 4;
        ctx.fillText('$' + value.toFixed(0), padding - 10, y);
    }
});
</script>

<?php require_once 'footer.php'; ?>
