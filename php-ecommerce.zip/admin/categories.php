<?php
session_start();
require_once '../inc/json_store.php';
require_once '../inc/security.php';

// Check admin authentication
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

$store = new JsonStore();
$categories = $store->read('categories');

// Handle form submissions
if ($_POST) {
    if (!verify_csrf_token($_POST['csrf_token'])) {
        die('CSRF token validation failed');
    }
    
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $new_category = [
                    'id' => uniqid(),
                    'name' => sanitize_input($_POST['name']),
                    'slug' => strtolower(str_replace(' ', '-', sanitize_input($_POST['name']))),
                    'description' => sanitize_input($_POST['description']),
                    'created_at' => date('Y-m-d H:i:s')
                ];
                $categories[] = $new_category;
                $store->write('categories', $categories);
                break;
                
            case 'edit':
                foreach ($categories as &$category) {
                    if ($category['id'] === $_POST['id']) {
                        $category['name'] = sanitize_input($_POST['name']);
                        $category['slug'] = strtolower(str_replace(' ', '-', sanitize_input($_POST['name'])));
                        $category['description'] = sanitize_input($_POST['description']);
                        break;
                    }
                }
                $store->write('categories', $categories);
                break;
                
            case 'delete':
                $categories = array_filter($categories, function($cat) {
                    return $cat['id'] !== $_POST['id'];
                });
                $store->write('categories', array_values($categories));
                break;
        }
    }
    header('Location: categories.php');
    exit;
}

include 'header.php';
?>

<div class="admin-content">
    <div class="admin-header">
        <h1>Category Management</h1>
        <button class="btn btn-primary" onclick="showAddModal()">Add New Category</button>
    </div>

    <div class="admin-card">
        <div class="table-responsive">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Slug</th>
                        <th>Description</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($categories as $category): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($category['name']); ?></td>
                        <td><?php echo htmlspecialchars($category['slug']); ?></td>
                        <td><?php echo htmlspecialchars($category['description']); ?></td>
                        <td><?php echo date('M j, Y', strtotime($category['created_at'])); ?></td>
                        <td>
                            <button class="btn btn-sm btn-secondary" onclick="editCategory('<?php echo $category['id']; ?>', '<?php echo htmlspecialchars($category['name']); ?>', '<?php echo htmlspecialchars($category['description']); ?>')">Edit</button>
                            <button class="btn btn-sm btn-danger" onclick="deleteCategory('<?php echo $category['id']; ?>')">Delete</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add/Edit Category Modal -->
<div id="categoryModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalTitle">Add New Category</h3>
            <span class="close" onclick="closeModal()">&times;</span>
        </div>
        <form id="categoryForm" method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
            <input type="hidden" name="action" id="formAction" value="add">
            <input type="hidden" name="id" id="categoryId">
            
            <div class="form-group">
                <label for="name">Category Name</label>
                <input type="text" id="name" name="name" required>
            </div>
            
            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description" rows="3"></textarea>
            </div>
            
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Category</button>
            </div>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>
