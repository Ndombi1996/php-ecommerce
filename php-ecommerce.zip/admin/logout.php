<?php
session_start();

// Clear admin session data
unset($_SESSION['admin_id']);
unset($_SESSION['admin_username']);
unset($_SESSION['admin_name']);

// Redirect to admin login
header('Location: /admin/index.php');
exit;
?>
