// Admin Dashboard JavaScript
document.addEventListener("DOMContentLoaded", () => {
  // Confirm delete actions
  const deleteButtons = document.querySelectorAll(".btn-danger")
  deleteButtons.forEach((button) => {
    button.addEventListener("click", (e) => {
      if (!confirm("Are you sure you want to delete this item? This action cannot be undone.")) {
        e.preventDefault()
      }
    })
  })

  // Auto-generate slug from title
  const titleInput = document.getElementById("title")
  const slugInput = document.getElementById("slug")

  if (titleInput && slugInput) {
    titleInput.addEventListener("input", function () {
      const slug = this.value
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "")
      slugInput.value = slug
    })
  }

  // Form validation
  const adminForms = document.querySelectorAll(".admin-form")
  adminForms.forEach((form) => {
    form.addEventListener("submit", (e) => {
      const requiredFields = form.querySelectorAll("[required]")
      let isValid = true

      requiredFields.forEach((field) => {
        if (!field.value.trim()) {
          field.classList.add("error")
          isValid = false
        } else {
          field.classList.remove("error")
        }
      })

      if (!isValid) {
        e.preventDefault()
        showToast("Please fill in all required fields", "error")
      }
    })
  })

  // Table row highlighting
  const tableRows = document.querySelectorAll(".admin-table tbody tr")
  tableRows.forEach((row) => {
    row.addEventListener("mouseenter", function () {
      this.style.backgroundColor = "var(--muted)"
    })

    row.addEventListener("mouseleave", function () {
      this.style.backgroundColor = ""
    })
  })

  // Status badge interactions
  const statusBadges = document.querySelectorAll(".status-badge")
  statusBadges.forEach((badge) => {
    badge.addEventListener("click", function () {
      // Could implement quick status change here
      console.log("[v0] Status badge clicked:", this.textContent)
    })
  })
})

// Utility functions for admin
function showToast(message, type = "info") {
  const toast = document.createElement("div")
  toast.className = `toast toast-${type}`
  toast.textContent = message

  document.body.appendChild(toast)

  setTimeout(() => toast.classList.add("show"), 100)

  setTimeout(() => {
    toast.classList.remove("show")
    setTimeout(() => document.body.removeChild(toast), 300)
  }, 3000)
}

function confirmAction(message = "Are you sure?") {
  return confirm(message)
}

// Chart utilities
function drawSimpleChart(canvas, data, options = {}) {
  const ctx = canvas.getContext("2d")
  const padding = options.padding || 40
  const chartWidth = canvas.width - padding * 2
  const chartHeight = canvas.height - padding * 2

  // Clear canvas
  ctx.clearRect(0, 0, canvas.width, canvas.height)

  // Draw basic chart structure
  ctx.strokeStyle = options.gridColor || "#e5e7eb"
  ctx.lineWidth = 1

  // Grid lines
  for (let i = 0; i <= 5; i++) {
    const y = padding + (chartHeight / 5) * i
    ctx.beginPath()
    ctx.moveTo(padding, y)
    ctx.lineTo(canvas.width - padding, y)
    ctx.stroke()
  }

  return ctx
}
