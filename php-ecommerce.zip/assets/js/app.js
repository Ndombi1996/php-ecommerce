// Modern E-commerce JavaScript
document.addEventListener("DOMContentLoaded", () => {
  // Mobile menu toggle
  const mobileMenuToggle = document.getElementById("mobileMenuToggle")
  const navMenu = document.getElementById("navMenu")

  if (mobileMenuToggle && navMenu) {
    mobileMenuToggle.addEventListener("click", () => {
      navMenu.classList.toggle("active")
      mobileMenuToggle.classList.toggle("active")
    })
  }

  // Help widget
  const helpToggle = document.getElementById("helpToggle")
  const helpPanel = document.getElementById("helpPanel")
  const helpClose = document.getElementById("helpClose")

  if (helpToggle && helpPanel) {
    helpToggle.addEventListener("click", () => {
      helpPanel.classList.toggle("active")
    })

    if (helpClose) {
      helpClose.addEventListener("click", () => {
        helpPanel.classList.remove("active")
      })
    }

    // Close help panel when clicking outside
    document.addEventListener("click", (e) => {
      if (!helpToggle.contains(e.target) && !helpPanel.contains(e.target)) {
        helpPanel.classList.remove("active")
      }
    })
  }

  // Product tabs
  const tabButtons = document.querySelectorAll(".tab-btn")
  const tabPanels = document.querySelectorAll(".tab-panel")

  tabButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const targetTab = this.dataset.tab

      // Remove active class from all buttons and panels
      tabButtons.forEach((btn) => btn.classList.remove("active"))
      tabPanels.forEach((panel) => panel.classList.remove("active"))

      // Add active class to clicked button and corresponding panel
      this.classList.add("active")
      document.getElementById(targetTab).classList.add("active")
    })
  })

  // Quantity controls
  const quantityControls = document.querySelectorAll(".quantity-controls")

  quantityControls.forEach((control) => {
    const decreaseBtn = control.querySelector('[data-action="decrease"]')
    const increaseBtn = control.querySelector('[data-action="increase"]')
    const input = control.querySelector(".qty-input")

    if (decreaseBtn && increaseBtn && input) {
      decreaseBtn.addEventListener("click", () => {
        const currentValue = Number.parseInt(input.value)
        const minValue = Number.parseInt(input.min) || 1
        if (currentValue > minValue) {
          input.value = currentValue - 1
          // Trigger change event for cart updates
          input.dispatchEvent(new Event("change"))
        }
      })

      increaseBtn.addEventListener("click", () => {
        const currentValue = Number.parseInt(input.value)
        const maxValue = Number.parseInt(input.max) || 999
        if (currentValue < maxValue) {
          input.value = currentValue + 1
          // Trigger change event for cart updates
          input.dispatchEvent(new Event("change"))
        }
      })
    }
  })

  // Add to cart functionality
  const addToCartButtons = document.querySelectorAll(".add-to-cart")

  addToCartButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const productId = this.dataset.productId
      const quantityInput = document.getElementById("quantity")
      const quantity = quantityInput ? Number.parseInt(quantityInput.value) : 1

      // Show loading state
      const originalText = this.textContent
      this.textContent = "Adding..."
      this.disabled = true

      // Send AJAX request to add item to cart
      fetch("/api/cart.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "add_to_cart",
          product_id: productId,
          quantity: quantity,
        }),
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            // Show success message
            showToast("Product added to cart!", "success")

            // Update cart count in header
            updateCartCount(data.cart_count)

            // Reset button
            this.textContent = originalText
            this.disabled = false
          } else {
            showToast(data.message || "Error adding product to cart", "error")
            this.textContent = originalText
            this.disabled = false
          }
        })
        .catch((error) => {
          console.error("[v0] Error adding to cart:", error)
          showToast("Error adding product to cart", "error")
          this.textContent = originalText
          this.disabled = false
        })
    })
  })

  // Buy now functionality
  const buyNowBtn = document.getElementById("buyNowBtn")
  if (buyNowBtn) {
    buyNowBtn.addEventListener("click", () => {
      const productId = document.querySelector(".add-to-cart").dataset.productId
      const quantityInput = document.getElementById("quantity")
      const quantity = quantityInput ? Number.parseInt(quantityInput.value) : 1

      // Add to cart and redirect to checkout
      fetch("/api/cart.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "add_to_cart",
          product_id: productId,
          quantity: quantity,
        }),
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            window.location.href = "/checkout.php"
          } else {
            showToast(data.message || "Error adding product to cart", "error")
          }
        })
        .catch((error) => {
          console.error("[v0] Error with buy now:", error)
          showToast("Error processing request", "error")
        })
    })
  }

  // Live chat placeholder
  const liveChatBtn = document.getElementById("liveChatBtn")
  if (liveChatBtn) {
    liveChatBtn.addEventListener("click", () => {
      showToast("Live chat will be available soon!", "info")
    })
  }
})

// Utility functions
function showToast(message, type = "info") {
  // Create toast element
  const toast = document.createElement("div")
  toast.className = `toast toast-${type}`
  toast.textContent = message

  // Add toast to page
  document.body.appendChild(toast)

  // Show toast with animation
  setTimeout(() => toast.classList.add("show"), 100)

  // Remove toast after 3 seconds
  setTimeout(() => {
    toast.classList.remove("show")
    setTimeout(() => document.body.removeChild(toast), 300)
  }, 3000)
}

function updateCartCount(count) {
  const cartCountElement = document.querySelector(".cart-count")
  if (cartCountElement) {
    cartCountElement.textContent = count

    // Add bounce animation
    cartCountElement.style.transform = "scale(1.2)"
    setTimeout(() => {
      cartCountElement.style.transform = "scale(1)"
    }, 200)
  }
}

// Form validation helpers
function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return re.test(email)
}

function validatePhone(phone) {
  const re = /^[+]?[1-9][\d]{0,15}$/
  return re.test(phone.replace(/\s/g, ""))
}

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault()
    const target = document.querySelector(this.getAttribute("href"))
    if (target) {
      target.scrollIntoView({
        behavior: "smooth",
        block: "start",
      })
    }
  })
})
