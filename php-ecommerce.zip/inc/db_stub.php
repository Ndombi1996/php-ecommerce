<?php
// Database stub for future migration to SQL DB
function get_db() {
    // Edit to add your DB credentials when migrating
    $host = '127.0.0.1';
    $db   = 'ecommerce';
    $user = 'dbuser';
    $pass = 'dbpass';
    $dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";
    $opts = [
       PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
       PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];
    try {
        return new PDO($dsn, $user, $pass, $opts);
    } catch (PDOException $e) {
        // In dev keep fallback to JSON; log the error
        error_log('DB connect failed: '.$e->getMessage());
        return null;
    }
}

// Example prepared statements for future migration
function get_products_db($pdo) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE status = ? ORDER BY created_at DESC");
    $stmt->execute(['active']);
    return $stmt->fetchAll();
}

function get_product_by_id_db($pdo, $id) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function create_order_db($pdo, $order_data) {
    $stmt = $pdo->prepare("INSERT INTO orders (id, user_id, items, subtotal, shipping, discount, total, status, created_at, payment) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    return $stmt->execute([
        $order_data['id'],
        $order_data['user_id'],
        json_encode($order_data['items']),
        $order_data['subtotal'],
        $order_data['shipping'],
        $order_data['discount'],
        $order_data['total'],
        $order_data['status'],
        $order_data['created_at'],
        json_encode($order_data['payment'])
    ]);
}
?>
