<?php
// Security utilities
class Security {
    public static function generate_csrf_token() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
    
    public static function verify_csrf_token($token) {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
    
    public static function sanitize_input($input) {
        if (is_array($input)) {
            return array_map([self::class, 'sanitize_input'], $input);
        }
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    }
    
    public static function hash_password($password) {
        return password_hash($password, PASSWORD_DEFAULT);
    }
    
    public static function verify_password($password, $hash) {
        return password_verify($password, $hash);
    }
    
    public static function is_logged_in() {
        return isset($_SESSION['user_id']);
    }
    
    public static function is_admin() {
        return isset($_SESSION['admin_id']);
    }
    
    public static function require_login() {
        if (!self::is_logged_in()) {
            header('Location: /auth/login.php');
            exit;
        }
    }
    
    public static function require_admin() {
        if (!self::is_admin()) {
            header('Location: /admin/index.php');
            exit;
        }
    }
}
?>
