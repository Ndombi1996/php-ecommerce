<?php
require_once __DIR__ . '/config.php';

// Get cart count for header
$cart_count = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cart_count += $item['quantity'];
    }
}

// Get categories for navigation
$categories = JsonStore::read_json('categories.json');
$visible_categories = array_filter($categories, function($cat) {
    return $cat['visible'] && (!isset($cat['status']) || $cat['status'] !== 'coming_soon');
});
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' : ''; ?><?php echo SITE_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;600;700&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
    <link href="/assets/css/style.css" rel="stylesheet">
    <meta name="description" content="<?php echo isset($page_description) ? $page_description : 'Quality household items at great prices'; ?>">
</head>
<body>
    <header class="header">
        <nav class="navbar">
            <div class="container">
                <div class="nav-brand">
                    <a href="/" class="brand-link">
                        <h1 class="brand-name"><?php echo SITE_NAME; ?></h1>
                    </a>
                </div>
                
                <div class="nav-menu" id="navMenu">
                    <a href="/" class="nav-link">Home</a>
                    <a href="/shop.php" class="nav-link">Shop</a>
                    <?php foreach ($visible_categories as $category): ?>
                        <a href="/shop.php?category=<?php echo urlencode($category['slug']); ?>" class="nav-link">
                            <?php echo htmlspecialchars($category['name']); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
                
                <div class="nav-actions">
                    <a href="/cart.php" class="cart-link">
                        <svg class="cart-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-1.5 6M7 13l-1.5 6m0 0h9M17 13v6a2 2 0 01-2 2H9a2 2 0 01-2-2v-6"></path>
                        </svg>
                        <span class="cart-count"><?php echo $cart_count; ?></span>
                    </a>
                    
                    <?php if (Security::is_logged_in()): ?>
                        <a href="/account/dashboard.php" class="nav-link">Account</a>
                        <a href="/auth/logout.php" class="nav-link">Logout</a>
                    <?php else: ?>
                        <a href="/auth/login.php" class="nav-link">Login</a>
                        <a href="/auth/register.php" class="nav-link">Register</a>
                    <?php endif; ?>
                </div>
                
                <button class="mobile-menu-toggle" id="mobileMenuToggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </div>
        </nav>
    </header>
    
    <main class="main-content">
