</main>
    
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3 class="footer-title"><?php echo SITE_NAME; ?></h3>
                    <p class="footer-text">Quality household items for your everyday needs.</p>
                </div>
                
                <div class="footer-section">
                    <h4 class="footer-subtitle">Quick Links</h4>
                    <ul class="footer-links">
                        <li><a href="/">Home</a></li>
                        <li><a href="/shop.php">Shop</a></li>
                        <li><a href="/about.php">About</a></li>
                        <li><a href="/contact.php">Contact</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4 class="footer-subtitle">Categories</h4>
                    <ul class="footer-links">
                        <?php foreach ($visible_categories as $category): ?>
                            <li>
                                <a href="/shop.php?category=<?php echo urlencode($category['slug']); ?>">
                                    <?php echo htmlspecialchars($category['name']); ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4 class="footer-subtitle">Support</h4>
                    <ul class="footer-links">
                        <li><a href="/help.php">Help Center</a></li>
                        <li><a href="/shipping.php">Shipping Info</a></li>
                        <li><a href="/returns.php">Returns</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>
    
    <!-- Help Widget -->
    <div class="help-widget" id="helpWidget">
        <button class="help-toggle" id="helpToggle">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
        </button>
        
        <div class="help-panel" id="helpPanel">
            <div class="help-header">
                <h3>Need Help?</h3>
                <button class="help-close" id="helpClose">&times;</button>
            </div>
            <div class="help-options">
                <a href="/help.php" class="help-option">
                    <span>📚</span>
                    <div>
                        <strong>FAQ</strong>
                        <p>Find answers to common questions</p>
                    </div>
                </a>
                <a href="/contact.php" class="help-option">
                    <span>✉️</span>
                    <div>
                        <strong>Email Support</strong>
                        <p>Send us a message</p>
                    </div>
                </a>
                <button class="help-option" id="liveChatBtn">
                    <span>💬</span>
                    <div>
                        <strong>Live Chat</strong>
                        <p>Chat with our team (Coming Soon)</p>
                    </div>
                </button>
            </div>
        </div>
    </div>
    
    <script src="/assets/js/app.js"></script>
</body>
</html>
