<?php
// Configuration settings
define('SITE_NAME', 'HouseholdHub');
define('SITE_URL', 'http://localhost');
define('CURRENCY', 'USD');
define('CURRENCY_SYMBOL', '$');

// Shipping settings
define('FREE_SHIPPING_THRESHOLD', 50.00);
define('STANDARD_SHIPPING_RATE', 5.99);
define('EXPRESS_SHIPPING_RATE', 12.99);

// Tax settings
define('TAX_RATE', 0.08); // 8%

// Referral settings
define('REFERRAL_DISCOUNT_PERCENT', 5);

// Email settings
define('ADMIN_EMAIL', 'admin@example.com');
define('FROM_EMAIL', 'noreply@example.com');

// Session settings
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 0); // Set to 1 for HTTPS

session_start();

// Include required files
require_once __DIR__ . '/json_store.php';
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/db_stub.php';
?>
