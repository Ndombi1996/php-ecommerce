<?php
// JSON helper utility for flat file storage
class JsonStore {
    private static $data_dir = __DIR__ . '/../data/';
    
    public static function read_json($file) {
        $filepath = self::$data_dir . $file;
        if (!file_exists($filepath)) {
            return [];
        }
        
        $content = file_get_contents($filepath);
        return json_decode($content, true) ?: [];
    }
    
    public static function write_json($file, $data) {
        $filepath = self::$data_dir . $file;
        
        // Ensure data directory exists
        if (!is_dir(self::$data_dir)) {
            mkdir(self::$data_dir, 0755, true);
        }
        
        // Use file locking to prevent race conditions
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        return file_put_contents($filepath, $json, LOCK_EX) !== false;
    }
    
    public static function generate_id($prefix = '') {
        return $prefix . uniqid() . '_' . time();
    }
    
    public static function find_by_id($file, $id) {
        $data = self::read_json($file);
        foreach ($data as $item) {
            if ($item['id'] === $id) {
                return $item;
            }
        }
        return null;
    }
    
    public static function update_by_id($file, $id, $updates) {
        $data = self::read_json($file);
        foreach ($data as $key => $item) {
            if ($item['id'] === $id) {
                $data[$key] = array_merge($item, $updates);
                return self::write_json($file, $data);
            }
        }
        return false;
    }
    
    public static function delete_by_id($file, $id) {
        $data = self::read_json($file);
        $data = array_filter($data, function($item) use ($id) {
            return $item['id'] !== $id;
        });
        return self::write_json($file, array_values($data));
    }
}
?>
