<?php
session_start();
require_once '../inc/config.php';

header('Content-Type: application/json');

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';

// Initialize cart if not exists
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

switch ($action) {
    case 'add_to_cart':
        $product_id = $input['product_id'] ?? '';
        $quantity = max(1, intval($input['quantity'] ?? 1));
        
        if (!$product_id) {
            echo json_encode(['success' => false, 'message' => 'Product ID required']);
            exit;
        }
        
        // Get product details
        $product = JsonStore::find_by_id('products.json', $product_id);
        if (!$product) {
            echo json_encode(['success' => false, 'message' => 'Product not found']);
            exit;
        }
        
        // Check stock
        if ($product['status'] !== 'active' || $product['stock'] < $quantity) {
            echo json_encode(['success' => false, 'message' => 'Product not available']);
            exit;
        }
        
        // Add to cart or update quantity
        if (isset($_SESSION['cart'][$product_id])) {
            $new_quantity = $_SESSION['cart'][$product_id]['quantity'] + $quantity;
            if ($new_quantity > $product['stock']) {
                echo json_encode(['success' => false, 'message' => 'Not enough stock available']);
                exit;
            }
            $_SESSION['cart'][$product_id]['quantity'] = $new_quantity;
        } else {
            $_SESSION['cart'][$product_id] = [
                'quantity' => $quantity,
                'added_at' => time()
            ];
        }
        
        // Calculate cart count
        $cart_count = 0;
        foreach ($_SESSION['cart'] as $item) {
            $cart_count += $item['quantity'];
        }
        
        echo json_encode([
            'success' => true, 
            'message' => 'Product added to cart',
            'cart_count' => $cart_count
        ]);
        break;
        
    case 'update_quantity':
        $product_id = $input['product_id'] ?? '';
        $quantity = max(0, intval($input['quantity'] ?? 0));
        
        if (!$product_id) {
            echo json_encode(['success' => false, 'message' => 'Product ID required']);
            exit;
        }
        
        if ($quantity === 0) {
            unset($_SESSION['cart'][$product_id]);
        } else {
            // Check stock
            $product = JsonStore::find_by_id('products.json', $product_id);
            if (!$product || $quantity > $product['stock']) {
                echo json_encode(['success' => false, 'message' => 'Invalid quantity']);
                exit;
            }
            
            if (isset($_SESSION['cart'][$product_id])) {
                $_SESSION['cart'][$product_id]['quantity'] = $quantity;
            }
        }
        
        echo json_encode(['success' => true, 'message' => 'Cart updated']);
        break;
        
    case 'remove_item':
        $product_id = $input['product_id'] ?? '';
        
        if (!$product_id) {
            echo json_encode(['success' => false, 'message' => 'Product ID required']);
            exit;
        }
        
        unset($_SESSION['cart'][$product_id]);
        
        echo json_encode(['success' => true, 'message' => 'Item removed from cart']);
        break;
        
    case 'get_cart':
        $cart_items = [];
        $products = JsonStore::read_json('products.json');
        
        foreach ($_SESSION['cart'] as $product_id => $cart_item) {
            $product = JsonStore::find_by_id('products.json', $product_id);
            if ($product) {
                $cart_items[] = [
                    'product' => $product,
                    'quantity' => $cart_item['quantity'],
                    'subtotal' => $product['price'] * $cart_item['quantity']
                ];
            }
        }
        
        echo json_encode(['success' => true, 'cart_items' => $cart_items]);
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        break;
}
?>
