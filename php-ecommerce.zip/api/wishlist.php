<?php
session_start();
require_once '../inc/json_store.php';
require_once '../inc/security.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';
$product_id = $input['product_id'] ?? '';

if (empty($action) || empty($product_id)) {
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
    exit;
}

$store = new JsonStore();
$users = $store->read('users');

// Find and update user
foreach ($users as &$user) {
    if ($user['id'] === $_SESSION['user_id']) {
        if (!isset($user['wishlist'])) {
            $user['wishlist'] = [];
        }
        
        if ($action === 'add') {
            if (!in_array($product_id, $user['wishlist'])) {
                $user['wishlist'][] = $product_id;
                $message = 'Added to wishlist';
            } else {
                $message = 'Already in wishlist';
            }
        } elseif ($action === 'remove') {
            $user['wishlist'] = array_values(array_filter($user['wishlist'], function($id) use ($product_id) {
                return $id !== $product_id;
            }));
            $message = 'Removed from wishlist';
        }
        
        $store->write('users', $users);
        echo json_encode(['success' => true, 'message' => $message]);
        exit;
    }
}

echo json_encode(['success' => false, 'message' => 'User not found']);
?>
