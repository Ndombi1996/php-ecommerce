<?php
session_start();
require_once '../inc/json_store.php';
require_once '../inc/security.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$payment_method = $_POST['payment_method'] ?? '';
$order_id = $_POST['order_id'] ?? '';

if (empty($payment_method) || empty($order_id)) {
    header('Location: ../checkout.php?error=missing_data');
    exit;
}

// Payment integration stubs
switch ($payment_method) {
    case 'paypal':
        // PayPal integration stub
        $payment_result = processPayPal($order_id);
        break;
    case 'stripe':
        // Stripe integration stub
        $payment_result = processStripe($order_id);
        break;
    case 'cash_on_delivery':
        $payment_result = ['success' => true, 'transaction_id' => 'COD_' . uniqid()];
        break;
    default:
        header('Location: ../checkout.php?error=invalid_method');
        exit;
}

if ($payment_result['success']) {
    // Update order status
    $store = new JsonStore();
    $orders = $store->read('orders');
    
    foreach ($orders as &$order) {
        if ($order['id'] === $order_id) {
            $order['status'] = 'paid';
            $order['payment_method'] = $payment_method;
            $order['transaction_id'] = $payment_result['transaction_id'];
            $order['paid_at'] = date('Y-m-d H:i:s');
            break;
        }
    }
    
    $store->write('orders', $orders);
    header('Location: ../checkout-success.php?order=' . $order_id);
} else {
    header('Location: ../checkout.php?error=payment_failed');
}

function processPayPal($order_id) {
    // PayPal API integration stub
    // In production, integrate with PayPal SDK
    return [
        'success' => true,
        'transaction_id' => 'PP_' . uniqid(),
        'message' => 'PayPal payment processed successfully'
    ];
}

function processStripe($order_id) {
    // Stripe API integration stub
    // In production, integrate with Stripe SDK
    return [
        'success' => true,
        'transaction_id' => 'ST_' . uniqid(),
        'message' => 'Stripe payment processed successfully'
    ];
}
?>
